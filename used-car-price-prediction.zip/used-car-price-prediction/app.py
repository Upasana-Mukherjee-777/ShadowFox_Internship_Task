"""
app.py - Streamlit app for the used car selling-price predictor.

Run from the project root:
    streamlit run app.py
"""

import sys
from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from predict import format_price, load_metadata, load_model, predict_price  # noqa: E402

st.set_page_config(page_title="Used Car Selling Price Prediction", page_icon="\U0001F697")


@st.cache_resource
def get_model():
    return load_model()


# --------------------------------------------------------------------------
# 1. Title and introduction
# --------------------------------------------------------------------------
st.title("Used Car Selling Price Prediction")
st.write(
    "This app estimates a fair resale price for a used car from a few details: "
    "its current showroom price, age, kilometers driven, fuel type, number of "
    "previous owners, seller type and transmission. The estimate comes from a "
    "Gradient Boosting regression model trained on 198 real used-car listings."
)

try:
    model = get_model()
    meta = load_metadata()
except FileNotFoundError:
    st.error("Model not found. Run `python src/train.py` first.")
    st.stop()

options = meta["categorical_options"]
ranges = meta["numeric_ranges_train"]

# --------------------------------------------------------------------------
# 2. Input form
# --------------------------------------------------------------------------
st.header("Enter car details")

left, right = st.columns(2)
with left:
    present_price = st.number_input(
        "Present (showroom) price, in lakhs \u20b9",
        min_value=0.0, value=round(ranges["Present_Price"]["median"], 2), step=0.1,
        help=f"Training data range: {ranges['Present_Price']['min']:.2f} "
             f"to {ranges['Present_Price']['max']:.2f} lakhs")
    car_age = st.number_input(
        "Car age, in years", min_value=0, max_value=40,
        value=int(ranges["Car_Age"]["median"]), step=1,
        help=f"Training data range: {int(ranges['Car_Age']['min'])} "
             f"to {int(ranges['Car_Age']['max'])} years")
    kms_driven = st.number_input(
        "Kilometers driven", min_value=0,
        value=int(ranges["Kms_Driven"]["median"]), step=1000,
        help=f"Training data range: {int(ranges['Kms_Driven']['min']):,} "
             f"to {int(ranges['Kms_Driven']['max']):,} km")
    owner = st.selectbox("Number of previous owners", options=[0, 1, 3],
                         help="0 = first owner")

with right:
    fuel_type = st.selectbox("Fuel type", options=options["Fuel_Type"])
    seller_type = st.selectbox("Seller type", options=options["Seller_Type"])
    transmission = st.selectbox("Transmission", options=options["Transmission"])

if fuel_type == "CNG":
    st.caption("Note: only 2 CNG cars appear in the training data, so CNG "
              "predictions are less reliable than Petrol or Diesel.")

# --------------------------------------------------------------------------
# 3 & 4. Predict button and result
# --------------------------------------------------------------------------
if st.button("Predict Selling Price", type="primary"):
    values = {
        "Present_Price": present_price, "Kms_Driven": kms_driven, "Car_Age": car_age,
        "Owner": owner, "Fuel_Type": fuel_type, "Seller_Type": seller_type,
        "Transmission": transmission,
    }
    price = predict_price(values, model)
    st.success(f"Estimated Selling Price: {format_price(price)}")
    if price > present_price:
        st.caption("Note: the estimate exceeds the entered showroom price, which is "
                  "unusual for a used car and outside the range the model was trained on.")
    st.caption(f"Model: {meta['model_name']} (tuned). Test-set performance: "
              "see the Model information section below.")

# --------------------------------------------------------------------------
# 5. Optional model information
# --------------------------------------------------------------------------
with st.expander("Model information"):
    st.write(f"**Algorithm:** {meta['model_name']} (tuned: {meta['tuned']})")
    st.write(f"**Best parameters:** {meta['best_params']}")
    st.write(f"**Trained on:** {meta['train_rows']} cars, tested on {meta['test_rows']} cars")
    st.write("**Test-set metrics** (from `outputs/results/final_model_metrics.json`):")
    try:
        import json
        metrics = json.loads((Path(__file__).resolve().parent /
                              "outputs/results/final_model_metrics.json").read_text())["test"]
        st.table(pd.DataFrame([metrics]).round(3))
    except FileNotFoundError:
        st.write("Metrics file not found.")
    st.caption("MAE/RMSE are in lakhs \u20b9. R\u00b2 is the share of price variation explained.")

# --------------------------------------------------------------------------
# 6. Optional basic EDA / model performance section
# --------------------------------------------------------------------------
with st.expander("Model performance charts"):
    plot_dir = Path(__file__).resolve().parent / "outputs" / "plots"
    for name, caption in [
        ("model_comparison.png", "Test RMSE and R\u00b2 across all models compared"),
        ("actual_vs_predicted.png", "Actual vs predicted selling price on the test set"),
        ("residual_analysis.png", "Residual analysis for the final model"),
        ("feature_importance.png", "Which features drive the prediction most"),
    ]:
        path = plot_dir / name
        if path.exists():
            st.image(str(path), caption=caption, width="stretch")

st.caption(
    "This is a student academic project trained on 198 historical listings. "
    "Predictions are estimates, not a valuation, and should not be used for "
    "real financial decisions."
)
