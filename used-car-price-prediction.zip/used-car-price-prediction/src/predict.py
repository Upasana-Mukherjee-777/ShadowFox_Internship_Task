"""
predict.py
----------
Load the saved pipeline and predict a used car's selling price.

Usage (from the project root):

    # 1. Predict for a real car from the held-out test set (demo)
    python src/predict.py --example

    # 2. Predict for your own values (JSON text or a .json file)
    python src/predict.py --json '{"Present_Price": 8.5, "Kms_Driven": 35000,
        "Car_Age": 4, "Owner": 0, "Fuel_Type": "Petrol",
        "Seller_Type": "Dealer", "Transmission": "Manual"}'

Because the saved file is a full sklearn Pipeline, the same one-hot
encoding (and scaling, if any) used in training is applied automatically.
"""

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

from preprocessing import ALL_FEATURES, PROJECT_ROOT, clean_data, load_raw_data, split_data

MODEL_PATH = PROJECT_ROOT / "models" / "final_model.pkl"
METADATA_PATH = PROJECT_ROOT / "models" / "model_metadata.json"


def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "models/final_model.pkl not found. Run  python src/train.py  first.")
    return joblib.load(MODEL_PATH)


def load_metadata():
    return json.loads(METADATA_PATH.read_text())


def predict_price(values, model=None):
    """
    Predict the selling price (in lakhs of INR) for one used car.

    values : dict with keys Present_Price, Kms_Driven, Car_Age, Owner,
             Fuel_Type, Seller_Type, Transmission.
    """
    model = model or load_model()

    unknown = set(values) - set(ALL_FEATURES)
    missing = [f for f in ALL_FEATURES if f not in values]
    if unknown:
        raise ValueError(f"Unknown feature(s): {sorted(unknown)}. Expected: {ALL_FEATURES}")
    if missing:
        raise ValueError(f"Missing feature(s): {missing}")

    row = pd.DataFrame([values], columns=ALL_FEATURES)
    return float(model.predict(row)[0])


def format_price(price_lakhs):
    return f"\u20b9{price_lakhs * 100000:,.0f}  ({price_lakhs:.2f} lakhs)"


def main():
    parser = argparse.ArgumentParser(description="Predict a used car's selling price.")
    parser.add_argument("--json", help="JSON string or path to a JSON file with feature values")
    parser.add_argument("--example", action="store_true",
                        help="predict for the first car of the held-out test set")
    args = parser.parse_args()

    model = load_model()

    if args.json:
        text = Path(args.json).read_text() if Path(args.json).exists() else args.json
        values = json.loads(text)
        print("Predicted selling price:", format_price(predict_price(values, model)))
    else:
        raw = load_raw_data()
        cars, _, _ = clean_data(raw)
        _, X_test, _, y_test = split_data(cars)
        values = X_test.iloc[0].to_dict()
        print("Input features (first car of the test set):")
        for name, value in values.items():
            print(f"  {name:<13} {value}")
        print("\nPredicted selling price:", format_price(predict_price(values, model)))
        print("Actual selling price   :", format_price(float(y_test.iloc[0])))


if __name__ == "__main__":
    main()
