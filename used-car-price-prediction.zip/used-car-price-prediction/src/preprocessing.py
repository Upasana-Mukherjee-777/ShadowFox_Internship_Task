"""
preprocessing.py
----------------
Loading, cleaning, feature engineering and the preprocessing pipeline for the
used-car selling-price project.

Everything that touches the raw data lives here so that the notebook, the
training script and the prediction script all use exactly the same logic.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# --------------------------------------------------------------------------
# Project-wide settings
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "car.csv"

TARGET_COLUMN = "Selling_Price"     # in lakhs of rupees, as stated by the source
RANDOM_STATE = 42
TEST_SIZE = 0.20

NUMERIC_FEATURES = ["Present_Price", "Kms_Driven", "Car_Age", "Owner"]
CATEGORICAL_FEATURES = ["Fuel_Type", "Seller_Type", "Transmission"]
ALL_FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES

# The raw file mixes cars with motorcycles/scooters (see README / report for
# the full explanation). These brand prefixes identify the two-wheeler rows.
TWO_WHEELER_BRAND_PREFIXES = [
    "Bajaj", "Hero", "Honda Activa", "Honda CB", "Honda Dream", "Honda Karizma",
    "Hyosung", "KTM", "Mahindra Mojo", "Royal Enfield", "Suzuki Access",
    "TVS", "UM", "Yamaha", "Activa",
]


# --------------------------------------------------------------------------
# Loading and cleaning
# --------------------------------------------------------------------------
def _is_two_wheeler(name):
    name = str(name).strip()
    return any(name.startswith(prefix) for prefix in TWO_WHEELER_BRAND_PREFIXES)


def load_raw_data(path=DATA_PATH):
    """Read the CSV exactly as supplied."""
    return pd.read_csv(path)


def filter_to_cars(df):
    """Remove the two-wheeler rows (motorcycles/scooters) that are mixed
    into the raw file. The assignment asks for CAR price prediction, and the
    two groups have non-overlapping price ranges, so combining them would
    distort the model. Returns (cars_df, two_wheelers_df)."""
    is_bike = df["Car_Name"].apply(_is_two_wheeler)
    return df.loc[~is_bike].copy(), df.loc[is_bike].copy()


def engineer_features(df, reference_year=None):
    """Add Car_Age = reference_year - Year.
    reference_year defaults to the maximum Year found in the data (the most
    recent model year on record), so it is derived from the data itself
    rather than hard-coded to an assumed 'today'."""
    df = df.copy()
    if reference_year is None:
        reference_year = int(df["Year"].max())
    df["Car_Age"] = reference_year - df["Year"]
    return df, reference_year


def clean_data(df):
    """Full cleaning pipeline applied once, right after loading:
    filter out two-wheelers, drop duplicate rows, engineer Car_Age.
    Returns (clean_df, two_wheelers_df, reference_year)."""
    cars, two_wheelers = filter_to_cars(df)
    cars = cars.drop_duplicates().reset_index(drop=True)
    cars, reference_year = engineer_features(cars)
    return cars, two_wheelers, reference_year


def inspect_data(df):
    """Basic facts about a dataframe, used for the notebook / report."""
    return {
        "shape": df.shape,
        "columns": list(df.columns),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "missing_counts": df.isna().sum().to_dict(),
        "duplicate_rows": int(df.duplicated().sum()),
        "constant_columns": [c for c in df.columns if df[c].nunique() <= 1],
    }


# --------------------------------------------------------------------------
# Feature / target split
# --------------------------------------------------------------------------
def split_xy(df):
    """Separate the input features X from the target y.
    Car_Name and Year are intentionally excluded (see README for why)."""
    return df[ALL_FEATURES].copy(), df[TARGET_COLUMN].copy()


def split_data(df):
    """80/20 train-test split with a fixed random_state."""
    X, y = split_xy(df)
    return train_test_split(X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE)


# --------------------------------------------------------------------------
# Preprocessing pipeline
# --------------------------------------------------------------------------
def build_preprocessor(scale):
    """
    Numeric features are optionally standardised (needed for Linear
    Regression, not for tree-based models). Categorical features are
    one-hot encoded - a good fit here because Fuel_Type, Seller_Type and
    Transmission each have only 2-3 possible values, so one-hot does not
    blow up the number of columns. `handle_unknown="ignore"` means a
    category never seen in training (e.g. a new Fuel_Type at prediction
    time) does not crash the pipeline - it is encoded as all zeros.

    There are no missing values in this dataset (confirmed at inspection
    time), so no imputer is included.
    """
    numeric_steps = [("scale", StandardScaler())] if scale else []
    numeric_pipeline = Pipeline(numeric_steps) if numeric_steps else "passthrough"

    categorical_pipeline = Pipeline([
        ("onehot", OneHotEncoder(handle_unknown="ignore", drop="if_binary")),
    ])

    return ColumnTransformer([
        ("numeric", numeric_pipeline, NUMERIC_FEATURES),
        ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
    ], verbose_feature_names_out=False)


def make_pipeline(model, scale):
    """Preprocessor + model glued together as one estimator."""
    return Pipeline([
        ("preprocess", build_preprocessor(scale)),
        ("model", model),
    ])
