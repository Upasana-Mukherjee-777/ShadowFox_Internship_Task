"""
train.py
--------
Compare a raw vs log-transformed target, train and compare four regression
models, pick the best one by cross-validation on the TRAINING data, tune it,
evaluate it once on the held-out test set, and save everything needed for
later predictions.

Run from the project root:
    python src/train.py
"""

import json
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV, KFold, cross_val_score, cross_validate
from sklearn.tree import DecisionTreeRegressor

from preprocessing import (ALL_FEATURES, PROJECT_ROOT, RANDOM_STATE,
                           TARGET_COLUMN, TEST_SIZE, clean_data, inspect_data,
                           load_raw_data, make_pipeline, split_data)
from evaluate import (MODEL_PATH, RESULTS_DIR, evaluate_pipeline,
                      plot_actual_vs_predicted, plot_feature_importance,
                      plot_model_comparison, plot_residuals,
                      plot_train_vs_test, regression_metrics)

CV_FOLDS = 5
CV = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)


# --------------------------------------------------------------------------
# Models to compare (the four required by the assignment)
# --------------------------------------------------------------------------
def get_models():
    """name -> (estimator, needs_scaling).
    Scaling matters for Linear Regression; trees do not need it."""
    return {
        "Linear Regression": (LinearRegression(), True),
        "Decision Tree": (DecisionTreeRegressor(max_depth=5, random_state=RANDOM_STATE), False),
        "Random Forest": (RandomForestRegressor(n_estimators=200, random_state=RANDOM_STATE), False),
        "Gradient Boosting": (GradientBoostingRegressor(random_state=RANDOM_STATE), False),
    }


# Small hyper-parameter grids for tuning the selected model.
PARAM_GRIDS = {
    "Decision Tree": {"model__max_depth": [3, 4, 5, 6, 8],
                      "model__min_samples_leaf": [1, 3, 5, 10]},
    "Random Forest": {"model__n_estimators": [200, 400],
                      "model__max_depth": [None, 6, 10],
                      "model__min_samples_leaf": [1, 2, 4]},
    "Gradient Boosting": {"model__n_estimators": [100, 200, 400],
                          "model__learning_rate": [0.03, 0.05, 0.1],
                          "model__max_depth": [2, 3, 4]},
}


def build_pipelines():
    return {name: make_pipeline(est, scale) for name, (est, scale) in get_models().items()}


# --------------------------------------------------------------------------
# Feature engineering check: does a log-transformed target help?
# --------------------------------------------------------------------------
def _rmse_scorer(estimator, X, y):
    pred = estimator.predict(X)
    return -np.sqrt(mean_squared_error(y, pred))


def compare_target_transform(X_train, y_train):
    """5-fold CV RMSE (in original lakh-rupee units) for every model, with
    and without a log1p target transform. Used to decide whether the log
    transform is worth using for the final model. Returns a DataFrame."""
    rows = {}
    for name, (est, scale) in get_models().items():
        pipe = make_pipeline(est, scale)
        raw_scores = cross_val_score(pipe, X_train, y_train, cv=CV, scoring=_rmse_scorer)

        log_pipe = TransformedTargetRegressor(
            regressor=make_pipeline(est, scale), func=np.log1p, inverse_func=np.expm1)
        log_scores = cross_val_score(log_pipe, X_train, y_train, cv=CV, scoring=_rmse_scorer)

        rows[name] = {"CV_RMSE_raw_target": -raw_scores.mean(),
                      "CV_RMSE_log_target": -log_scores.mean()}
    return pd.DataFrame(rows).T


# --------------------------------------------------------------------------
# Steps
# --------------------------------------------------------------------------
def cross_validate_models(pipelines, X_train, y_train):
    """5-fold cross-validation on the training data only.
    The test set is never touched here, so it cannot influence model choice."""
    rows = {}
    for name, pipe in pipelines.items():
        scores = cross_validate(
            pipe, X_train, y_train, cv=CV,
            scoring={"rmse": "neg_root_mean_squared_error",
                     "mae": "neg_mean_absolute_error", "r2": "r2"})
        rows[name] = {
            "CV_RMSE_mean": -scores["test_rmse"].mean(),
            "CV_RMSE_std": scores["test_rmse"].std(),
            "CV_MAE_mean": -scores["test_mae"].mean(),
            "CV_R2_mean": scores["test_r2"].mean(),
            "CV_R2_std": scores["test_r2"].std(),
        }
    return pd.DataFrame(rows).T


def fit_and_evaluate(pipelines, X_train, y_train, X_test, y_test):
    rows = {}
    for name, pipe in pipelines.items():
        pipe.fit(X_train, y_train)
        rows[name] = evaluate_pipeline(pipe, X_train, y_train, X_test, y_test)
    return pd.DataFrame(rows).T


def choose_best_model(cv_table):
    """Lowest mean cross-validated RMSE on the training data."""
    return cv_table["CV_RMSE_mean"].idxmin()


def tune_model(name, pipeline, X_train, y_train):
    grid = PARAM_GRIDS.get(name)
    if grid is None:
        return None
    search = GridSearchCV(pipeline, grid, cv=CV,
                          scoring="neg_root_mean_squared_error", n_jobs=-1)
    search.fit(X_train, y_train)
    return search


def get_importances(pipeline):
    """Feature importances of a fitted tree-based pipeline, as a Series."""
    names = pipeline[:-1].get_feature_names_out()
    return pd.Series(pipeline[-1].feature_importances_, index=names).sort_values(ascending=False)


def save_artifacts(final_pipeline, best_name, tuned, best_params, X_train, X_test,
                   train_metrics, test_metrics, cv_rmse_untuned, cv_rmse_tuned,
                   reference_year):
    """Save the fitted pipeline (preprocessing + model) with joblib, plus a
    small metadata file used by predict.py and the Streamlit app."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(final_pipeline, MODEL_PATH)
    metadata = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "model_name": best_name,
        "tuned": bool(tuned),
        "best_params": best_params,
        "target": TARGET_COLUMN,
        "target_unit": "lakhs of INR",
        "features": ALL_FEATURES,
        "reference_year_for_car_age": reference_year,
        "random_state": RANDOM_STATE,
        "test_size": TEST_SIZE,
        "train_rows": len(X_train),
        "test_rows": len(X_test),
        "categorical_options": {
            "Fuel_Type": sorted(X_train["Fuel_Type"].unique().tolist()),
            "Seller_Type": sorted(X_train["Seller_Type"].unique().tolist()),
            "Transmission": sorted(X_train["Transmission"].unique().tolist()),
        },
        "numeric_ranges_train": {
            c: {"min": float(X_train[c].min()), "median": float(X_train[c].median()),
                "max": float(X_train[c].max())}
            for c in ["Present_Price", "Kms_Driven", "Car_Age", "Owner"]
        },
    }
    (PROJECT_ROOT / "models" / "model_metadata.json").write_text(json.dumps(metadata, indent=2))
    (RESULTS_DIR / "final_model_metrics.json").write_text(json.dumps({
        "model": best_name, "tuned": bool(tuned), "best_params": best_params,
        "train": train_metrics, "test": test_metrics,
        "cv_rmse_untuned": cv_rmse_untuned, "cv_rmse_tuned": cv_rmse_tuned,
    }, indent=2))


# --------------------------------------------------------------------------
# Main workflow
# --------------------------------------------------------------------------
def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)

    raw = load_raw_data()
    cars, two_wheelers, reference_year = clean_data(raw)
    two_wheelers.to_csv(RESULTS_DIR / "excluded_two_wheelers.csv", index=False)
    print(f"Raw file: {len(raw)} rows | two-wheelers removed: {len(two_wheelers)} | "
          f"cars remaining: {len(cars)} | reference year for Car_Age: {reference_year}")

    X_train, X_test, y_train, y_test = split_data(cars)
    print(f"Features used: {ALL_FEATURES} | train: {len(X_train)} | test: {len(X_test)}")

    # 0. Feature-engineering check: does a log target help?
    transform_table = compare_target_transform(X_train, y_train)
    transform_table.to_csv(RESULTS_DIR / "target_transform_comparison.csv")
    print("\nRaw vs log-target CV RMSE (5-fold, training data):")
    print(transform_table.round(3))

    # 1. Cross-validation on the training data -> model selection (raw target)
    pipelines = build_pipelines()
    cv_table = cross_validate_models(pipelines, X_train, y_train)
    cv_table.to_csv(RESULTS_DIR / "cv_results.csv")
    print("\nCross-validation, raw target (training data only):")
    print(cv_table.round(3))

    # 2. Fit all models and score on train and test
    comparison = fit_and_evaluate(pipelines, X_train, y_train, X_test, y_test)
    comparison = comparison.join(cv_table[["CV_RMSE_mean", "CV_R2_mean"]])
    print("\nTrain / test metrics (default settings):")
    print(comparison.round(3))

    # 3. Choose and tune the best model (decision uses CV only, not test data)
    best_name = choose_best_model(cv_table)
    print(f"\nLowest CV RMSE: {best_name}")
    baseline_cv_rmse = cv_table.loc[best_name, "CV_RMSE_mean"]

    search = tune_model(best_name, build_pipelines()[best_name], X_train, y_train)
    final_pipeline = pipelines[best_name]
    tuned = False
    best_params = {}
    if search is not None:
        tuned_cv_rmse = -search.best_score_
        print(f"Tuned CV RMSE {tuned_cv_rmse:.3f} vs untuned {baseline_cv_rmse:.3f}")
        print("Best parameters:", search.best_params_)
        if tuned_cv_rmse < baseline_cv_rmse:
            final_pipeline = search.best_estimator_
            tuned = True
            best_params = search.best_params_
    else:
        tuned_cv_rmse = None

    # 4. Final evaluation on the untouched test set
    train_pred = final_pipeline.predict(X_train)
    test_pred = final_pipeline.predict(X_test)
    train_metrics = regression_metrics(y_train, train_pred)
    test_metrics = regression_metrics(y_test, test_pred)
    print("\nFinal model:", best_name, "(tuned)" if tuned else "(default settings)")
    print("  Train:", {k: round(v, 4) for k, v in train_metrics.items()})
    print("  Test :", {k: round(v, 4) for k, v in test_metrics.items()})

    # Add the tuned final model as an extra row of the comparison table
    if tuned:
        tuned_row = evaluate_pipeline(final_pipeline, X_train, y_train, X_test, y_test)
        tuned_row["CV_RMSE_mean"] = tuned_cv_rmse
        comparison.loc[f"{best_name} (tuned)"] = pd.Series(tuned_row)
    comparison.to_csv(RESULTS_DIR / "model_comparison.csv")

    # 5. Plots
    plot_model_comparison(comparison)
    plot_train_vs_test(comparison)
    plot_actual_vs_predicted(
        y_test, test_pred, f"Actual vs predicted selling price - {best_name} (test set)")
    plot_residuals(y_test, test_pred, best_name)
    rf_importance = get_importances(pipelines["Random Forest"])
    rf_importance.to_csv(RESULTS_DIR / "feature_importance_random_forest.csv",
                         header=["importance"])
    plot_feature_importance(rf_importance, "Random Forest feature importance (training data)")

    # 6. Save the model (preprocessing + estimator in ONE pipeline) + metadata
    save_artifacts(final_pipeline, best_name, tuned, best_params, X_train, X_test,
                   train_metrics, test_metrics, baseline_cv_rmse, tuned_cv_rmse,
                   reference_year)
    (RESULTS_DIR / "dataset_inspection_raw.json").write_text(
        json.dumps(inspect_data(raw), indent=2, default=str))
    (RESULTS_DIR / "dataset_inspection_cars.json").write_text(
        json.dumps(inspect_data(cars), indent=2, default=str))
    print(f"\nSaved model to {MODEL_PATH.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
