# Viva Preparation: 35 Questions and Answers

Numbers quoted come from `outputs/results/`. Prices are in lakhs of INR.

## A. Basic concepts

**1. Why is this a regression problem?**
`Selling_Price` is a continuous number (e.g. 4.75, 23.5), not a category, so the task is regression rather than classification.

**2. Why is `Selling_Price` the target variable?**
It is the only column that represents "selling price" as named in the problem statement, is numeric, continuous, and has no missing values.

**3. What are the input features?**
`Present_Price`, `Kms_Driven`, `Car_Age` (engineered), `Owner`, `Fuel_Type`, `Seller_Type`, `Transmission`.

**4. Why isn't `Car_Name` used as a feature?**
It has 37 unique values across only 198 rows — too high-cardinality to one-hot encode reliably with this little data, and the assignment's feature list does not include car model as an input.

## B. Data quality and preprocessing

**5. What was the most important finding during dataset inspection?**
The raw 301-row file mixes 200 actual cars with 101 motorcycles/scooters (brands like Bajaj, Hero, Royal Enfield, TVS, Yamaha). Since the assignment is specifically about car prices, the two-wheeler rows were excluded, because their price range (₹0.10–1.75L) barely overlaps with cars (₹0.35–35L) and mixing them would distort the model.

**6. How did you detect the two-wheeler rows?**
By reading through the unique `Car_Name` values — brand names clearly belonging to motorcycle/scooter manufacturers stood out, and checking their price and fuel-type patterns confirmed they form a distinct, consistent group.

**7. Were there missing values?**
No — the dataset has zero missing values in any column, confirmed by `.isna().sum()`.

**8. Were there duplicate rows?**
Yes, two exact duplicates among the 200 car rows (an `ertiga` and a `fortuner`, each appearing twice), removed to avoid double-counting the same listing.

**9. How did you handle categorical variables?**
With One-Hot Encoding for `Fuel_Type`, `Seller_Type` and `Transmission` — each has only 2–3 values, so one-hot does not create too many columns and avoids implying a false order between categories.

**10. Why use `handle_unknown="ignore"` in the encoder?**
So that a category never seen during training (e.g. a new Fuel_Type at prediction time) does not crash the pipeline — it is simply encoded as all zeros.

**11. Why scale some models and not others?**
Linear Regression is sensitive to differences in feature scale (e.g. `Present_Price` in single digits vs `Kms_Driven` in the tens of thousands); tree-based models only compare a feature against thresholds, so scaling does not affect them.

**12. What is data leakage, and how did you avoid it?**
Letting information from the test data influence training, e.g. fitting a scaler on the whole dataset before splitting. I avoided it by putting scaling and encoding inside a scikit-learn `Pipeline`, fit only on training data.

**13. How did you handle outliers?**
I inspected them rather than removing them automatically. High-value cars (Land Cruiser, Fortuner) and high-mileage old cars are genuine listings, not data errors, so they were kept — though one of them (the Land Cruiser) is discussed in detail in the error analysis.

## C. Feature engineering

**14. What is `Car_Age` and why did you create it?**
`Car_Age = reference_year − Year`, where `reference_year` is the latest model year in the data (2018). It directly represents "years of service", which the assignment explicitly asks for, and is more interpretable than the raw manufacture year.

**15. Why did you test a log transform on the target?**
`Selling_Price` is right-skewed (skewness 2.70). A log transform often helps models handle skewed targets, so I tested it properly with cross-validation instead of assuming it would help.

**16. What did the log-transform test show?**
It reduced cross-validated RMSE for Linear Regression (1.866→1.649) and the Decision Tree (1.841→1.501), but was very slightly worse for Gradient Boosting (1.158 vs 1.173) — the eventual best model. So the final model keeps the raw target, based on the measured result.

**17. Did you add interaction features?**
No — with only 198 rows and 7 features, added interaction terms would risk overfitting without clear justification from the EDA, so the feature set was kept simple as the assignment asked.

## D. Train/test split and models

**18. Why split into train and test sets?**
To measure performance on cars the model has never seen. Scoring on the training data alone would just show how well the model memorised the answers.

**19. Why 80/20?**
A common convention that leaves enough data to learn from (158 cars) while keeping a meaningful holdout (40 cars).

**20. What does `random_state=42` do?**
Fixes the random shuffle, so the same split and results are obtained every time the code runs.

**21. Why Linear Regression?**
As a simple, interpretable baseline to see how far a straight-line model gets before trying more complex ones.

**22. Why Decision Tree?**
It captures non-linear relationships and needs no scaling, but a single tree (even at depth 5) can be unstable, motivating the ensemble methods.

**23. Why Random Forest?**
It averages many trees trained on random samples of the data and features, which reduces the overfitting risk of one tree.

**24. Why Gradient Boosting?**
It builds trees sequentially, each correcting the previous ones' errors, and often gives the best accuracy on tabular data like this — confirmed here by its lowest cross-validated RMSE.

## E. Evaluation

**25. Why MAE?**
It is the average absolute prediction error, in the same unit as price (lakhs), and is not overly sensitive to one large mistake — useful here given the Land Cruiser outlier.

**26. Why RMSE?**
It penalises large errors more heavily than MAE, which is useful for flagging cases (like the Land Cruiser) where the model badly under-predicts.

**27. What does R² mean?**
The share of the variation in selling price the model explains; 1 is perfect, 0 is no better than predicting the average price every time.

**28. What is cross-validation, and why did you use it?**
Splitting the training data into folds (five here), training on some and validating on the rest, repeated so every fold is validated once, then averaging the scores. It gives a steadier estimate than one split and was used to choose the model without touching the test set.

**29. How was the final model selected?**
By the lowest cross-validated RMSE on the training data (Gradient Boosting, 1.158), not by looking at the test set first. Tuning then improved it slightly to 1.136.

**30. Why is the test R² (0.769) lower than the cross-validated R² (0.938)?**
One car — a Land Cruiser at ₹92.6L showroom price, the most expensive in the dataset — landed in the 40-row test set and was badly under-predicted (₹35L actual vs ₹19.15L predicted), because the model has very little training data in that price range. Excluding just this one car, test RMSE drops from 2.79 to 1.24, close to the cross-validated figure.

**31. What is overfitting, and did it happen here?**
The model fitting training-specific detail too closely, performing much better on training data than on new data. Yes — the tuned Gradient Boosting model reaches training R² 0.999 but test R² 0.769, a clear gap expected with a flexible model on only 158 training rows.

## F. Interpretability and deployment

**32. What is feature importance, and what did you find?**
It measures how much each feature contributes to a tree-based model's predictions. `Present_Price` dominates (about 0.80 of Random Forest importance), followed by `Car_Age` (about 0.14) — matching the correlation analysis.

**33. How does the prediction pipeline work end-to-end?**
`predict_price()` loads the saved pipeline (one-hot encoder + model, saved together with `joblib`), checks that all seven required features are supplied, passes them through the same encoding used in training, and returns the model's price estimate.

**34. Why Streamlit for deployment?**
It turns a Python script into a usable web form with very little code, well suited to demonstrating a small academic project without building a full front end.

**35. How would you improve this project?**
Collect more cars, especially in the higher price range; try a log-target Gradient Boosting with a wider hyper-parameter search; try XGBoost or LightGBM; add SHAP explanations for individual predictions; use car brand as a lower-cardinality feature instead of dropping `Car_Name` entirely; validate on more current data.
