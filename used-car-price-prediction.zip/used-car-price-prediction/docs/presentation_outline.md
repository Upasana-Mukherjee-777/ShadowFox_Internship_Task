# Presentation Outline (12 slides, about 10 minutes)

Figure files are in `outputs/plots/`. Speaker notes are written to be said in your own words.

---

## Slide 1 - Title

**Bullets**
- Used Car Selling Price Prediction using Machine Learning
- Your name, programme (B.Tech CSE AI & ML, 3rd year), institution, date

**Show:** title text, or a screenshot of the Streamlit app's title.

**Say:** "Good morning. My project estimates the resale price of a used car from features like its showroom price, age and mileage, using regression."

---

## Slide 2 - Problem Statement

**Bullets**
- Predict a car's approximate selling price from fuel type, age, showroom price, previous owners, kilometers driven, seller type, transmission
- Supervised learning, regression (price is a continuous number)

**Show:** the problem statement quote.

**Say:** "The goal was set out clearly: build a model that gives users an approximate selling price from a handful of everyday car facts."

---

## Slide 3 - Motivation

**Bullets**
- Buyers and sellers often don't know a fair resale price
- A quick, data-driven estimate helps both sides negotiate
- Good introductory project: real messy data, clear regression target

**Show:** none needed - a short spoken slide.

**Say:** "Used-car pricing is often guesswork. A model trained on real listings can give a quick, defensible starting estimate, and the dataset here has enough real-world messiness to make the exercise genuinely instructive."

---

## Slide 4 - Objectives

**Bullets**
- Inspect the data without assuming its structure
- Clean it and engineer a car-age feature
- Compare 4 regression models with cross-validation
- Evaluate honestly, select and save a final model
- Deploy with Streamlit

**Show:** the six-step pipeline: Inspect -> Clean -> Explore -> Train 4 models -> Evaluate -> Deploy.

**Say:** "I wanted a complete, honest pipeline, not just a model - including catching problems in the data before they reached the model."

---

## Slide 5 - Dataset

**Bullets**
- `car.csv`: 301 rows, 9 columns, no missing values
- Key finding: 101 of 301 rows are actually motorcycles, not cars
- After removing them and 2 duplicates: 198 cars used for modelling
- Target: `Selling_Price` (lakhs ₹)

**Show:** the two-wheeler-vs-car price comparison table, or `01_target_distribution.png`.

**Say:** "The file's name suggested cars only, but on inspection, a third of the rows were actually motorcycles and scooters - Bajaj, Hero, Royal Enfield and so on - with a completely different price range. Since the assignment asked specifically about car prices, I excluded them, which is the single most important decision in this project."

---

## Slide 6 - Data Preprocessing

**Bullets**
- One-Hot Encoding for Fuel_Type, Seller_Type, Transmission (2-3 values each)
- Scaling only for Linear Regression; not needed for tree models
- No missing values, so no imputation needed
- Engineered `Car_Age` from Year; dropped high-cardinality `Car_Name`
- Everything inside a Pipeline to avoid data leakage

**Show:** a simple diagram: raw columns -> encode/scale (fit on train only) -> model.

**Say:** "Preprocessing choices were matched to what the data actually needed - simple encoding for a few low-cardinality categories, scaling only where the model needs it, and everything wrapped in a pipeline so the test data never leaks into training."

---

## Slide 7 - EDA

**Bullets**
- Present_Price correlates strongly with Selling_Price (r = 0.82)
- Car_Age correlates moderately (r = -0.35); retained-value ratio much more strongly (r = -0.86)
- Diesel and Automatic cars sell for more on average (likely segment effects)

**Show:** `03_correlation_heatmap.png` and `07_depreciation_vs_age.png`.

**Say:** "A car's showroom price is by far the strongest signal for its resale price. Age matters most when you look at it as a fraction of the car's value retained, not as a raw number of years."

---

## Slide 8 - ML Methodology

**Bullets**
- 4 models: Linear Regression, Decision Tree, Random Forest, Gradient Boosting
- 80/20 train-test split, random_state=42
- 5-fold cross-validation on training data for model selection
- Tested a log-transformed target for the skewed price - decided against it based on real results

**Show:** the model table from the report (one line per model: idea, strength, limitation).

**Say:** "I compared four models fairly using cross-validation, and even tested whether transforming the skewed price target would help - it did for the simpler models, but not for the one I ended up selecting, so I kept the raw price."

---

## Slide 9 - Model Comparison

**Bullets**
- CV RMSE: Gradient Boosting 1.16, Random Forest 1.24, Decision Tree 1.84, Linear Regression 1.87
- Gradient Boosting selected; tuning improved CV RMSE to 1.14
- Test-set RMSE looked worse than CV at first glance - investigated, not ignored

**Show:** `model_comparison.png`.

**Say:** "Gradient Boosting was clearly ahead in cross-validation. Tuning its settings improved it a little further."

---

## Slide 10 - Final Results

**Bullets**
- Test MAE 1.19 lakh, RMSE 2.79 lakh, R² 0.77
- One Land Cruiser (₹92.6L showroom price) explains most of that RMSE
- Excluding it, RMSE drops to 1.24 lakh - close to the cross-validated estimate
- Present_Price is the dominant feature (~80% of importance)

**Show:** `actual_vs_predicted.png` (the Land Cruiser point is clearly visible).

**Say:** "The headline test score looks a bit disappointing until you look closer: one very expensive, rarely-seen car accounts for most of the error. I think it's important to show that honestly rather than hide it."

---

## Slide 11 - Deployment / Demo

**Bullets**
- Streamlit app: enter car details, press Predict, get an estimate
- Loads the saved pipeline once - no retraining per click
- Optional sections show model info and performance charts

**Show:** a screenshot of the app after pressing Predict, or run it live.

**Say:** "Here I enter a car's details and get an instant estimate. The app uses the exact same preprocessing pipeline that was used in training, so there's no mismatch between training and deployment."

---

## Slide 12 - Conclusion & Future Scope

**Bullets**
- Careful inspection caught a major data issue before it reached the model
- Gradient Boosting selected on real cross-validated evidence
- Present_Price and Car_Age are the key drivers of price
- Future: more high-value cars, XGBoost/LightGBM, SHAP explanations, brand as a feature

**Show:** a short summary slide, optionally `train_vs_test_r2.png`.

**Say:** "To conclude: the project delivers a complete, honestly-evaluated pipeline and a working demo. With more data, especially in the higher price range, and a wider search over model settings, the results could improve further. Thank you - happy to take questions."
