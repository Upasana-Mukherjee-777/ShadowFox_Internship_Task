# Used Car Selling Price Prediction

A regression project that estimates the resale price of a used car from its showroom price, age, mileage, fuel type, transmission, seller type and number of previous owners. It covers dataset inspection, cleaning, exploratory analysis, feature engineering, comparison of four models, evaluation, a saved final model, a prediction script and a Streamlit deployment.

## Problem statement

> Develop an ML model for car selling price prediction and analysis. The deployed system will provide users with an approximate selling price for their cars based on several features, including fuel type, years of service, showroom price, number of previous owners, kilometers driven, whether the seller is a dealer or an individual, and transmission type.

## Objectives

1. Inspect the provided dataset without assuming it matches a known template.
2. Clean the data and engineer a car-age feature.
3. Explore the data to see which features relate to price.
4. Train and compare Linear Regression, Decision Tree, Random Forest and Gradient Boosting.
5. Evaluate with MAE, MSE, RMSE and R² using cross-validation, select a final model and save it.
6. Provide a prediction function and a Streamlit app that use the exact same preprocessing as training.

## Dataset

| Item | Value |
|---|---|
| File | `data/car.csv` |
| Raw size | 301 rows, 9 columns |
| Target | `Selling_Price` (lakhs of INR) |
| Missing values | none |

**Important finding.** The raw file mixes **200 cars with 101 motorcycles/scooters** (Bajaj, Hero, Honda Activa/CB/CBR/Karizma, Hyosung, KTM, Mahindra Mojo, Royal Enfield, Suzuki Access, TVS, UM, Yamaha), identifiable by brand name in `Car_Name`. The two groups have non-overlapping price ranges (two-wheelers: ₹0.10–1.75L; cars: ₹0.35–35L) and two-wheelers are 100% Petrol. Since the assignment asks specifically for **car** price prediction, the two-wheeler rows are excluded from modelling (saved to `outputs/results/excluded_two_wheelers.csv`, not silently discarded). Two exact duplicate rows are also removed. **The cleaned dataset used for modelling has 198 rows.**

**Features used:** `Present_Price`, `Kms_Driven`, `Car_Age` (engineered), `Owner`, `Fuel_Type`, `Seller_Type`, `Transmission`.
**Not used:** `Car_Name` (37 unique values across 198 rows — too high-cardinality to one-hot encode reliably, and not in the assignment's feature list) and raw `Year` (replaced by `Car_Age`).

## Technologies

Python 3, pandas, NumPy, matplotlib, seaborn, scikit-learn, joblib, Jupyter, Streamlit.

## Machine learning approach

1. Load the CSV, filter out two-wheelers, drop duplicates, engineer `Car_Age = reference_year - Year` (reference year = the latest model year present in the data, 2018).
2. Split 80% / 20% into training (158) and test (40) sets, `random_state=42`.
3. Build a scikit-learn `Pipeline`: one-hot encoding for the 3 categorical columns, standard scaling for Linear Regression only, then the model. Everything fits on training data only, preventing data leakage.
4. Compare four models with 5-fold cross-validation on the training data.
5. Test whether a log-transformed target helps (Feature Engineering) — it helps the weaker models but not the best one, so the final model keeps the raw target.
6. Pick the model with the lowest cross-validated RMSE, tune it with a small grid search, and evaluate once on the test set.
7. Save the whole pipeline with `joblib` and use it for predictions.

## Preprocessing

- **Categorical encoding:** One-Hot Encoding for `Fuel_Type`, `Seller_Type`, `Transmission` — each has only 2–3 values, so one-hot does not create an excessive number of columns and avoids imposing a false order. `handle_unknown="ignore"` protects predictions against an unseen category.
- **Scaling:** StandardScaler, applied only inside the Linear Regression pipeline (tree-based models do not need it).
- **Missing values:** none present, so no imputation step is needed.
- **Outliers:** inspected, not removed — high-value cars (Land Cruiser, Fortuner) and high-mileage old cars are genuine listings, not data errors (see Results below for how one of them affects the test-set score).

## Models tested

Linear Regression, Decision Tree (`max_depth=5`), Random Forest (200 trees), Gradient Boosting.

## Evaluation metrics

MAE (average absolute error, lakhs ₹), MSE (average squared error), RMSE (square root of MSE, same unit as price), R² (share of price variation explained).

## Results

All figures below come from the run stored in `outputs/results/` (test set = 40 cars; errors in lakhs ₹).

| Model | MAE | MSE | RMSE | R² | CV RMSE (train) |
|---|---|---|---|---|---|
| Linear Regression | 1.395 | 6.785 | 2.605 | 0.799 | 1.866 |
| Decision Tree | 1.475 | 12.354 | 3.515 | 0.634 | 1.841 |
| Random Forest | 1.133 | 7.186 | 2.681 | 0.787 | 1.239 |
| Gradient Boosting | 1.192 | 8.805 | 2.967 | 0.739 | 1.158 |
| **Gradient Boosting (tuned) - final** | **1.193** | **7.784** | **2.790** | **0.769** | 1.136 |

* **Model selection used cross-validation, not the test-set table above.** By CV RMSE, Gradient Boosting (1.16) clearly beats Random Forest (1.24), which beats Decision Tree (1.84) and Linear Regression (1.87).
* **Why the test R² (0.77) looks lower than the CV R² (0.94):** a single Land Cruiser (Present_Price ₹92.6L, the most expensive car by far in the dataset) landed in the 40-row test set and was under-predicted (₹35L actual vs ₹19.15L predicted). Excluding just this one car, test RMSE falls from 2.79 to 1.24 — very close to the cross-validated estimate. This is reported honestly rather than hidden; see `report.md` Section 12 for the full analysis.
* `Present_Price` dominates feature importance (~0.80 in the Random Forest), followed by `Car_Age` (~0.14).
* A log-transformed target was tested (`outputs/results/target_transform_comparison.csv`): it helps Linear Regression (1.866→1.649) and the Decision Tree (1.841→1.501) but is neutral-to-slightly-worse for Gradient Boosting (1.158 vs 1.173), so the final model keeps the raw target.

## Real results versus limitations

* Every number above was produced by running the code in this repository; nothing is estimated or copied.
* The Streamlit app was tested with Streamlit's headless `AppTest` (load and press *Predict*), not opened in a browser during development.
* The dataset is small (198 cars after cleaning) and skewed toward mid-range cars, so predictions for premium cars (>₹20L) carry more uncertainty — visible directly in the Land Cruiser miss above.
* Only 2 CNG cars and 5 individually-sold cars exist in the whole dataset, so predictions for those categories are less reliable.

## Installation

```bash
cd used-car-price-prediction
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## How to run

**Notebook (full walkthrough with explanations and plots)**

```bash
jupyter notebook notebooks/used_car_price_analysis.ipynb
```

**Train from the command line**

```bash
python src/train.py
python src/evaluate.py      # reloads the saved model and re-checks the test metrics
```

**Prediction system**

```bash
python src/predict.py --example
python src/predict.py --json '{"Present_Price": 8.5, "Kms_Driven": 35000, "Car_Age": 4, "Owner": 0, "Fuel_Type": "Petrol", "Seller_Type": "Dealer", "Transmission": "Manual"}'
```

All seven features must be supplied. On Windows, save the JSON to a file (e.g. `car.json`) and pass `--json car.json` instead of quoting it on the command line.

```python
from predict import predict_price          # run from inside src/
predict_price({"Present_Price": 8.5, "Kms_Driven": 35000, "Car_Age": 4, "Owner": 0,
               "Fuel_Type": "Petrol", "Seller_Type": "Dealer", "Transmission": "Manual"})
```

## How to run Streamlit

```bash
streamlit run app.py
```

Enter the car's details, press **Predict Selling Price**, and the estimate appears. Expand **Model information** and **Model performance charts** for details.

## Example usage

Input: showroom price ₹8.5L, 4 years old, 35,000 km, Petrol, Dealer, Manual, no previous owners → the model estimates **₹5.78 lakhs** (verified by running `src/predict.py --json` with these exact values).

## Project structure

```
used-car-price-prediction/
├── data/
│   └── car.csv                       # the provided dataset (unchanged)
├── notebooks/
│   └── used_car_price_analysis.ipynb
├── src/
│   ├── preprocessing.py              # loading, cleaning, feature engineering, pipeline
│   ├── train.py                      # model comparison, tuning, saving
│   ├── evaluate.py                   # metrics and evaluation plots
│   └── predict.py                    # prediction from the saved model
├── models/
│   ├── final_model.pkl               # saved pipeline (preprocessing + model)
│   └── model_metadata.json           # feature list, categories, training ranges
├── outputs/
│   ├── plots/                        # all figures (PNG)
│   └── results/                      # comparison tables, metrics, excluded rows
├── docs/
│   ├── viva_questions.md             # 35 viva questions with answers
│   └── presentation_outline.md       # 12-slide presentation plan
├── app.py                            # Streamlit interface
├── README.md
├── report.md
├── requirements.txt
└── .gitignore
```

This follows the suggested structure, with `app.py` added for the required deployment phase and `docs/` for the viva and presentation material.

## Project novelty / value addition

**Basic implementation:** load data, train one or more regressors, report metrics.

**Value-added in this project:**
- A genuine data-quality investigation (the mixed cars/two-wheelers issue) rather than assuming the file's structure.
- Model comparison across 4 algorithms with 5-fold cross-validation, not a single train/test split.
- Small hyper-parameter grid search for the selected model.
- An explicit, measured test of whether a log-transformed target helps, rather than applying it by convention.
- Feature importance (Random Forest and the final model).
- Honest error analysis explaining *why* the test R² is lower than the cross-validated R² (Land Cruiser case study), instead of only reporting the number.
- A saved, reusable pipeline and a working Streamlit deployment that reads the same pipeline (no retraining on each prediction).

**Not claimed:** none of the above is a research contribution — they are standard good practice for an applied ML project, applied thoroughly.

**Possible future research directions:** collecting more high-value cars, per-prediction explanations (SHAP), brand-level features, and comparison against gradient-boosting libraries (XGBoost/LightGBM).

## Future scope

Collect more high-value cars for better coverage of the price range; test a log-target Gradient Boosting with a wider search; try XGBoost/LightGBM; extract car brand as a lower-cardinality feature; add SHAP-based per-prediction explanations; revisit CNG/Individual-seller pricing once more data exists.
