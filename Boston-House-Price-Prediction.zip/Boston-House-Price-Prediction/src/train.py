"""
train.py
--------
Train and compare several regression models, pick the best one using
cross-validation on the TRAINING data, tune it, evaluate it once on the
held-out test set, and save everything needed for later predictions.

Run from the project root:
    python src/train.py
"""

import json
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import GridSearchCV, KFold, cross_validate
from sklearn.tree import DecisionTreeRegressor

from data_preprocessing import (INCLUDE_B, PROJECT_ROOT, RANDOM_STATE,
                                TARGET_COLUMN, TEST_SIZE, inspect_data,
                                load_data, make_pipeline, split_data)
from evaluate import (MODEL_PATH, RESULTS_DIR, evaluate_pipeline,
                      plot_actual_vs_predicted, plot_feature_importance,
                      plot_model_comparison, plot_residuals,
                      plot_train_vs_test, regression_metrics)

CV_FOLDS = 5
CV = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)


# --------------------------------------------------------------------------
# Models to compare
# --------------------------------------------------------------------------
def get_models():
    """name -> (estimator, needs_scaling).
    Scaling matters for Linear/Ridge Regression; trees do not need it."""
    return {
        "Linear Regression": (LinearRegression(), True),
        "Ridge Regression": (Ridge(alpha=1.0, random_state=RANDOM_STATE), True),
        "Decision Tree": (DecisionTreeRegressor(max_depth=5, random_state=RANDOM_STATE), False),
        "Random Forest": (RandomForestRegressor(n_estimators=200, random_state=RANDOM_STATE), False),
        "Gradient Boosting": (GradientBoostingRegressor(random_state=RANDOM_STATE), False),
    }


# Small hyper-parameter grids used to tune the selected model.
PARAM_GRIDS = {
    "Ridge Regression": {"model__alpha": [0.01, 0.1, 1, 10, 100]},
    "Decision Tree": {"model__max_depth": [3, 4, 5, 6, 8],
                      "model__min_samples_leaf": [1, 3, 5, 10]},
    "Random Forest": {"model__n_estimators": [200, 500],
                      "model__max_depth": [None, 10],
                      "model__min_samples_leaf": [1, 2, 4]},
    "Gradient Boosting": {"model__n_estimators": [100, 200, 400],
                          "model__learning_rate": [0.03, 0.05, 0.1],
                          "model__max_depth": [2, 3, 4]},
}


def build_pipelines(feature_names):
    """One un-fitted Pipeline (preprocessing + model) per model name."""
    return {name: make_pipeline(feature_names, est, scale)
            for name, (est, scale) in get_models().items()}


# --------------------------------------------------------------------------
# Steps
# --------------------------------------------------------------------------
def cross_validate_models(pipelines, X_train, y_train):
    """5-fold cross-validation on the training data only.
    The test set is never touched here, so it cannot influence model choice."""
    rows = {}
    for name, pipe in pipelines.items():
        scores = cross_validate(
            pipe, X_train, y_train, cv=CV,
            scoring={"rmse": "neg_root_mean_squared_error",
                     "mae": "neg_mean_absolute_error", "r2": "r2"})
        rows[name] = {
            "CV_RMSE_mean": -scores["test_rmse"].mean(),
            "CV_RMSE_std": scores["test_rmse"].std(),
            "CV_MAE_mean": -scores["test_mae"].mean(),
            "CV_R2_mean": scores["test_r2"].mean(),
            "CV_R2_std": scores["test_r2"].std(),
        }
    return pd.DataFrame(rows).T


def fit_and_evaluate(pipelines, X_train, y_train, X_test, y_test):
    """Fit every pipeline on the training set and score it on train and test."""
    rows = {}
    for name, pipe in pipelines.items():
        pipe.fit(X_train, y_train)
        rows[name] = evaluate_pipeline(pipe, X_train, y_train, X_test, y_test)
    return pd.DataFrame(rows).T


def choose_best_model(cv_table):
    """Lowest mean cross-validated RMSE on the training data."""
    return cv_table["CV_RMSE_mean"].idxmin()


def tune_model(name, pipeline, X_train, y_train):
    """Grid search (5-fold CV, training data only) for the selected model.
    Returns the search object, or None if the model has nothing to tune."""
    grid = PARAM_GRIDS.get(name)
    if grid is None:
        return None
    search = GridSearchCV(pipeline, grid, cv=CV,
                          scoring="neg_root_mean_squared_error", n_jobs=-1)
    search.fit(X_train, y_train)
    return search


def get_importances(pipeline):
    """Feature importances of a fitted tree-based pipeline, as a Series."""
    names = pipeline[:-1].get_feature_names_out()
    return pd.Series(pipeline[-1].feature_importances_, index=names).sort_values(ascending=False)


def save_artifacts(final_pipeline, best_name, tuned, best_params, X_train, X_test,
                   train_metrics, test_metrics, cv_rmse_untuned, cv_rmse_tuned):
    """Save the fitted pipeline (preprocessing + model) with joblib, plus a
    small metadata file used by predict.py and the Streamlit app."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    feature_names = list(X_train.columns)
    joblib.dump(final_pipeline, MODEL_PATH)
    metadata = {
        "created": datetime.now().isoformat(timespec="seconds"),
        "model_name": best_name,
        "tuned": bool(tuned),
        "best_params": best_params,
        "target": TARGET_COLUMN,
        "features": feature_names,
        "include_B": INCLUDE_B,
        "random_state": RANDOM_STATE,
        "test_size": TEST_SIZE,
        "train_rows": len(X_train),
        "test_rows": len(X_test),
        "feature_stats_train": {
            c: {"min": float(X_train[c].min()), "median": float(X_train[c].median()),
                "max": float(X_train[c].max())} for c in feature_names},
    }
    (PROJECT_ROOT / "models" / "model_metadata.json").write_text(json.dumps(metadata, indent=2))
    (RESULTS_DIR / "final_model_metrics.json").write_text(json.dumps({
        "model": best_name, "tuned": bool(tuned), "best_params": best_params,
        "train": train_metrics, "test": test_metrics,
        "cv_rmse_untuned": cv_rmse_untuned, "cv_rmse_tuned": cv_rmse_tuned,
    }, indent=2))


# --------------------------------------------------------------------------
# Main workflow
# --------------------------------------------------------------------------
def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)

    df = load_data()
    X_train, X_test, y_train, y_test = split_data(df)
    feature_names = list(X_train.columns)
    print(f"Rows: {len(df)} | features used: {len(feature_names)} | "
          f"train: {len(X_train)} | test: {len(X_test)}")
    print("Features:", feature_names)

    # 1. Cross-validation on the training data -> model selection
    pipelines = build_pipelines(feature_names)
    cv_table = cross_validate_models(pipelines, X_train, y_train)
    cv_table.to_csv(RESULTS_DIR / "cv_results.csv")
    print("\nCross-validation (training data only):")
    print(cv_table.round(3))

    # 2. Fit all models and score on train and test
    comparison = fit_and_evaluate(pipelines, X_train, y_train, X_test, y_test)
    comparison = comparison.join(cv_table[["CV_RMSE_mean", "CV_R2_mean"]])
    print("\nTrain / test metrics (default settings):")
    print(comparison.round(3))

    # 3. Choose and tune the best model (decision uses CV only, not test data)
    best_name = choose_best_model(cv_table)
    print(f"\nLowest CV RMSE: {best_name}")
    baseline_cv_rmse = cv_table.loc[best_name, "CV_RMSE_mean"]

    search = tune_model(best_name, build_pipelines(feature_names)[best_name],
                        X_train, y_train)
    final_pipeline = pipelines[best_name]          # untuned, already fitted
    tuned = False
    best_params = {}
    if search is not None:
        tuned_cv_rmse = -search.best_score_
        print(f"Tuned CV RMSE {tuned_cv_rmse:.3f} vs untuned {baseline_cv_rmse:.3f}")
        print("Best parameters:", search.best_params_)
        if tuned_cv_rmse < baseline_cv_rmse:
            final_pipeline = search.best_estimator_
            tuned = True
            best_params = search.best_params_

    # 4. Final evaluation on the untouched test set
    train_pred = final_pipeline.predict(X_train)
    test_pred = final_pipeline.predict(X_test)
    train_metrics = regression_metrics(y_train, train_pred)
    test_metrics = regression_metrics(y_test, test_pred)
    print("\nFinal model:", best_name, "(tuned)" if tuned else "(default settings)")
    print("  Train:", {k: round(v, 4) for k, v in train_metrics.items()})
    print("  Test :", {k: round(v, 4) for k, v in test_metrics.items()})

    # Add the tuned final model as an extra row of the comparison table
    if tuned:
        tuned_row = evaluate_pipeline(final_pipeline, X_train, y_train, X_test, y_test)
        tuned_row["CV_RMSE_mean"] = -search.best_score_
        comparison.loc[f"{best_name} (tuned)"] = pd.Series(tuned_row)
    comparison.to_csv(RESULTS_DIR / "model_comparison.csv")

    # 5. Plots
    plot_model_comparison(comparison)
    plot_train_vs_test(comparison)
    plot_actual_vs_predicted(
        y_test, test_pred,
        f"Actual vs predicted prices - {best_name} (test set)")
    plot_residuals(y_test, test_pred, best_name)
    rf_importance = get_importances(pipelines["Random Forest"])
    rf_importance.to_csv(RESULTS_DIR / "feature_importance_random_forest.csv",
                         header=["importance"])
    plot_feature_importance(rf_importance, "Random Forest feature importance (training data)")

    # 6. Save the model (preprocessing + estimator in ONE pipeline) + metadata
    save_artifacts(final_pipeline, best_name, tuned, best_params, X_train, X_test,
                   train_metrics, test_metrics, baseline_cv_rmse,
                   -search.best_score_ if search is not None else None)
    (RESULTS_DIR / "dataset_inspection.json").write_text(
        json.dumps(inspect_data(df), indent=2, default=str))
    print(f"\nSaved model to {MODEL_PATH.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
