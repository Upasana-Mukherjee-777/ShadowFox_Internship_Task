"""
data_preprocessing.py
---------------------
Loading, inspecting and preprocessing the housing dataset.

Everything that touches the raw data lives here so that the notebook,
the training script, the prediction script and the Streamlit app all use
exactly the same logic.
"""

from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

# --------------------------------------------------------------------------
# Project-wide settings
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_PATH = PROJECT_ROOT / "data" / "HousingData.csv"

TARGET_COLUMN = "MEDV"          # identified after inspecting the file
RANDOM_STATE = 42               # fixed seed -> reproducible results
TEST_SIZE = 0.20                # 80 % train / 20 % test

# Column "B" is derived from the proportion of Black residents in a town.
# It is ethically problematic, so it is excluded from the model by default.
# Set INCLUDE_B = True to use all 13 original features instead.
INCLUDE_B = False
SENSITIVE_COLUMNS = ["B"]

# CHAS is a 0/1 flag (river bordering), so its missing values are filled with
# the most frequent value; all other features use the median.
BINARY_COLUMNS = ["CHAS"]


# --------------------------------------------------------------------------
# Loading and inspection
# --------------------------------------------------------------------------
def load_data(path=DATA_PATH):
    """Read the CSV. The file marks missing values with the text 'NA',
    which pandas converts to NaN automatically."""
    return pd.read_csv(path)


def inspect_data(df):
    """Return a dictionary of basic facts about the raw dataset."""
    return {
        "shape": df.shape,
        "columns": list(df.columns),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "missing_counts": df.isna().sum().to_dict(),
        "rows_with_any_missing": int(df.isna().any(axis=1).sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "constant_columns": [c for c in df.columns if df[c].nunique() <= 1],
    }


def get_feature_columns(df):
    """Feature names actually used by the model (target removed,
    sensitive column removed unless INCLUDE_B is True)."""
    features = [c for c in df.columns if c != TARGET_COLUMN]
    if not INCLUDE_B:
        features = [c for c in features if c not in SENSITIVE_COLUMNS]
    return features


def split_xy(df):
    """Separate the input features X from the target y."""
    features = get_feature_columns(df)
    return df[features].copy(), df[TARGET_COLUMN].copy()


def split_data(df):
    """80/20 train-test split with a fixed random_state."""
    X, y = split_xy(df)
    return train_test_split(X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE)


# --------------------------------------------------------------------------
# Preprocessing pipeline
# --------------------------------------------------------------------------
def build_preprocessor(feature_names, scale):
    """
    Build the preprocessing step.

    * Missing values are imputed (median, or most frequent for 0/1 columns).
    * If scale=True, features are standardised (mean 0, std 1).

    The imputer and scaler are *fitted only on the training data* when the
    full Pipeline is fitted, which prevents data leakage.
    """
    binary = [c for c in feature_names if c in BINARY_COLUMNS]
    numeric = [c for c in feature_names if c not in BINARY_COLUMNS]

    numeric_steps = [("impute", SimpleImputer(strategy="median"))]
    binary_steps = [("impute", SimpleImputer(strategy="most_frequent"))]
    if scale:
        numeric_steps.append(("scale", StandardScaler()))
        binary_steps.append(("scale", StandardScaler()))

    transformers = [("numeric", Pipeline(numeric_steps), numeric)]
    if binary:
        transformers.append(("binary", Pipeline(binary_steps), binary))

    # verbose_feature_names_out=False keeps original column names, which
    # makes feature importances easy to read.
    return ColumnTransformer(transformers, verbose_feature_names_out=False)


def make_pipeline(feature_names, model, scale):
    """Preprocessor + model glued together as one estimator."""
    return Pipeline([
        ("preprocess", build_preprocessor(feature_names, scale)),
        ("model", model),
    ])
