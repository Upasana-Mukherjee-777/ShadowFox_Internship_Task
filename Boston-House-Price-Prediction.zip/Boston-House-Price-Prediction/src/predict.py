"""
predict.py
----------
Load the saved pipeline and predict a house price from feature values.

Usage (from the project root):

    # 1. Predict for a real house from the held-out test set (demo)
    python src/predict.py --example

    # 2. Predict for your own values (JSON text or a .json file)
    python src/predict.py --json '{"CRIM": 0.1, "ZN": 0, "INDUS": 7.0, "CHAS": 0,
        "NOX": 0.5, "RM": 6.5, "AGE": 60, "DIS": 4.0, "RAD": 4, "TAX": 300,
        "PTRATIO": 18, "LSTAT": 10}'

Because the saved file is a full sklearn Pipeline, the same imputation and
scaling used in training is applied automatically to new input.
"""

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

from data_preprocessing import PROJECT_ROOT, load_data, split_data

MODEL_PATH = PROJECT_ROOT / "models" / "best_model.pkl"
METADATA_PATH = PROJECT_ROOT / "models" / "model_metadata.json"


def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "models/best_model.pkl not found. Run  python src/train.py  first.")
    return joblib.load(MODEL_PATH)


def load_metadata():
    return json.loads(METADATA_PATH.read_text())


def predict_price(values, model=None):
    """
    Predict the house price (in $1000s) for one house.

    values : dict mapping every feature name to a number.
             A value of None is treated as missing and is filled with the
             training-data median by the saved pipeline.
    """
    model = model or load_model()
    features = load_metadata()["features"]

    unknown = set(values) - set(features)
    missing = [f for f in features if f not in values]
    if unknown:
        raise ValueError(f"Unknown feature(s): {sorted(unknown)}. Expected: {features}")
    if missing:
        raise ValueError(f"Missing feature(s): {missing}")

    row = pd.DataFrame([values], columns=features).astype(float)  # None -> NaN
    return float(model.predict(row)[0])


def format_price(price_thousands):
    return f"${price_thousands * 1000:,.0f}  ({price_thousands:.2f} in $1000s)"


def main():
    parser = argparse.ArgumentParser(description="Predict a Boston house price.")
    parser.add_argument("--json", help="JSON string or path to a JSON file with feature values")
    parser.add_argument("--example", action="store_true",
                        help="predict for the first house of the held-out test set")
    args = parser.parse_args()

    model = load_model()

    if args.json:
        text = Path(args.json).read_text() if Path(args.json).exists() else args.json
        values = json.loads(text)
        print("Predicted price:", format_price(predict_price(values, model)))
    else:
        # Default demo: a genuine house from the test split (not used in training)
        df = load_data()
        _, X_test, _, y_test = split_data(df)
        values = X_test.iloc[0].where(X_test.iloc[0].notna(), None).to_dict()
        print("Input features (first house of the test set):")
        for name, value in values.items():
            print(f"  {name:<8} {value}")
        print("\nPredicted price:", format_price(predict_price(values, model)))
        print("Actual price   :", format_price(float(y_test.iloc[0])))


if __name__ == "__main__":
    main()
