"""
evaluate.py
-----------
Regression metrics and evaluation plots.

Run directly (python src/evaluate.py) to reload the saved model and check
that it reproduces the test-set metrics stored in outputs/results/.
"""

import json
import sys

import joblib
import matplotlib

if "ipykernel" not in sys.modules:   # plain script: no pop-up windows needed
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from data_preprocessing import PROJECT_ROOT, load_data, split_data

sns.set_theme(style="whitegrid")

PLOTS_DIR = PROJECT_ROOT / "outputs" / "plots"
RESULTS_DIR = PROJECT_ROOT / "outputs" / "results"
MODEL_PATH = PROJECT_ROOT / "models" / "best_model.pkl"


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------
def regression_metrics(y_true, y_pred):
    """MAE, MSE, RMSE and R2 for one set of predictions."""
    mse = mean_squared_error(y_true, y_pred)
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "MSE": mse,
        "RMSE": float(np.sqrt(mse)),
        "R2": r2_score(y_true, y_pred),
    }


def evaluate_pipeline(pipeline, X_train, y_train, X_test, y_test):
    """Train and test metrics for an already-fitted pipeline."""
    train = regression_metrics(y_train, pipeline.predict(X_train))
    test = regression_metrics(y_test, pipeline.predict(X_test))
    row = {f"Train_{k}": v for k, v in train.items()}
    row.update({f"Test_{k}": v for k, v in test.items()})
    return row


# --------------------------------------------------------------------------
# Plots (each one: title, axis labels, saved to outputs/plots/)
# --------------------------------------------------------------------------
def _finish(fig, filename):
    if filename is not None:
        PLOTS_DIR.mkdir(parents=True, exist_ok=True)
        fig.savefig(PLOTS_DIR / filename, dpi=150, bbox_inches="tight")
    return fig


def plot_model_comparison(results, filename="model_comparison.png"):
    """Side-by-side bar charts of test RMSE (lower is better) and test R2
    (higher is better). `results` is a DataFrame indexed by model name."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8))

    rmse = results["Test_RMSE"].sort_values()
    sns.barplot(x=rmse.values, y=rmse.index, ax=axes[0], color="#4C72B0")
    axes[0].set_title("Test RMSE by model (lower is better)")
    axes[0].set_xlabel("RMSE (target units, $1000s)")
    axes[0].set_ylabel("Model")
    for i, v in enumerate(rmse.values):
        axes[0].text(v + 0.03, i, f"{v:.2f}", va="center")

    r2 = results["Test_R2"].sort_values(ascending=False)
    sns.barplot(x=r2.values, y=r2.index, ax=axes[1], color="#55A868")
    axes[1].set_title("Test R\u00b2 by model (higher is better)")
    axes[1].set_xlabel("R\u00b2 score")
    axes[1].set_ylabel("Model")
    axes[1].set_xlim(0, 1)
    for i, v in enumerate(r2.values):
        axes[1].text(v + 0.01, i, f"{v:.3f}", va="center")

    fig.tight_layout()
    return _finish(fig, filename)


def plot_train_vs_test(results, filename="train_vs_test_r2.png"):
    """Grouped bars comparing training R2 with test R2 for every model.
    A big gap between the two is a sign of overfitting."""
    data = results[["Train_R2", "Test_R2"]].rename(
        columns={"Train_R2": "Training R\u00b2", "Test_R2": "Test R\u00b2"})
    ax = data.plot(kind="bar", figsize=(10, 4.8), color=["#DD8452", "#4C72B0"])
    ax.set_title("Training vs test R\u00b2 (a large gap suggests overfitting)")
    ax.set_xlabel("Model")
    ax.set_ylabel("R\u00b2 score")
    ax.set_ylim(0, 1.05)
    plt.xticks(rotation=25, ha="right")
    fig = ax.get_figure()
    fig.tight_layout()
    return _finish(fig, filename)


def plot_actual_vs_predicted(y_true, y_pred, title, filename="actual_vs_predicted.png"):
    """Scatter of actual vs predicted price with the perfect-prediction line."""
    fig, ax = plt.subplots(figsize=(6.5, 6))
    ax.scatter(y_true, y_pred, alpha=0.7, edgecolor="k", linewidth=0.4, color="#4C72B0")
    low = min(np.min(y_true), np.min(y_pred))
    high = max(np.max(y_true), np.max(y_pred))
    ax.plot([low, high], [low, high], "r--", label="Perfect prediction (y = x)")
    ax.set_title(title)
    ax.set_xlabel("Actual price, MEDV ($1000s)")
    ax.set_ylabel("Predicted price ($1000s)")
    ax.legend()
    ax.set_aspect("equal", adjustable="box")
    fig.tight_layout()
    return _finish(fig, filename)


def plot_residuals(y_true, y_pred, title_prefix, filename="residual_analysis.png"):
    """Residual histogram and residuals-vs-predicted plot.
    residual = actual - predicted."""
    residuals = np.asarray(y_true) - np.asarray(y_pred)
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8))

    sns.histplot(residuals, bins=25, kde=True, ax=axes[0], color="#4C72B0")
    axes[0].axvline(0, color="r", linestyle="--")
    axes[0].set_title(f"{title_prefix}: distribution of residuals")
    axes[0].set_xlabel("Residual = actual - predicted ($1000s)")
    axes[0].set_ylabel("Number of houses")

    axes[1].scatter(y_pred, residuals, alpha=0.7, edgecolor="k", linewidth=0.4,
                    color="#55A868")
    axes[1].axhline(0, color="r", linestyle="--")
    axes[1].set_title(f"{title_prefix}: residuals vs predicted price")
    axes[1].set_xlabel("Predicted price ($1000s)")
    axes[1].set_ylabel("Residual ($1000s)")

    fig.tight_layout()
    return _finish(fig, filename), residuals


def plot_feature_importance(importances, title, filename="feature_importance.png"):
    """Horizontal bar chart. `importances` is a Series indexed by feature."""
    data = importances.sort_values()
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.barh(data.index, data.values, color="#4C72B0")
    ax.set_title(title)
    ax.set_xlabel("Importance (share of total)")
    ax.set_ylabel("Feature")
    fig.tight_layout()
    return _finish(fig, filename)


# --------------------------------------------------------------------------
# Stand-alone check: reload the saved model and re-score it on the test split
# --------------------------------------------------------------------------
def main():
    if not MODEL_PATH.exists():
        raise SystemExit("No saved model found. Run  python src/train.py  first.")

    df = load_data()
    _, X_test, _, y_test = split_data(df)
    model = joblib.load(MODEL_PATH)
    metrics = regression_metrics(y_test, model.predict(X_test))

    print("Saved model re-scored on the held-out test set:")
    for name, value in metrics.items():
        print(f"  {name:<5}: {value:.4f}")

    stored_path = RESULTS_DIR / "final_model_metrics.json"
    if stored_path.exists():
        stored = json.loads(stored_path.read_text())["test"]
        same = all(abs(stored[k] - metrics[k]) < 1e-9 for k in metrics)
        print("Matches metrics stored by train.py:", "YES" if same else "NO")


if __name__ == "__main__":
    main()
