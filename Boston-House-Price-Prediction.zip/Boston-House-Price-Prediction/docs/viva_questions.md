# Viva Preparation: 40 Questions and Answers

Numbers quoted for this project come from `outputs/results/`. Prices are in $1000s (assuming the unit of the original dataset).

## A. Basic concepts

**1. What is regression?**
Regression predicts a continuous numerical value (here, a house price) from input features.

**2. Why is this a regression problem and not classification?**
The target `MEDV` is a continuous number such as 21.6 or 34.7. Classification predicts categories (for example "cheap / expensive").

**3. What is supervised learning?**
Learning from examples that come with the correct answer. The model sees features `X` and the known target `y` during training and learns the mapping between them.

**4. What is the target variable?**
`MEDV`, the median house price. It is the value the model must predict.

**5. What are features?**
The input columns used to make the prediction. Here there are 12: `CRIM, ZN, INDUS, CHAS, NOX, RM, AGE, DIS, RAD, TAX, PTRATIO, LSTAT`.

**6. How did you decide that `MEDV` is the target?**
I inspected the file. `MEDV` is the only column that represents the price, it is numeric and continuous, has no missing values, and is the last column.

## B. Data and preprocessing

**7. What did you find in the dataset?**
506 rows and 14 columns, no duplicates, and 20 missing values each in `CRIM, ZN, INDUS, CHAS, AGE, LSTAT`. In total 112 rows (22 %) had at least one missing value.

**8. How did you handle missing values, and why?**
By imputation: median for numeric columns, most frequent value for `CHAS`. Dropping incomplete rows would have removed 22 % of the data. The median is robust to extreme values such as those in `CRIM`.

**9. Why did you use the median and not the mean?**
`CRIM` is very skewed (median 0.25, maximum 88.98). A mean would be pulled upward by a few extreme values; the median is not.

**10. Why do we split the dataset into training and test sets?**
To measure performance on data the model has never seen. Evaluating on the training data would only show how well it memorised the answers.

**11. Why 80:20?**
It is a common convention. It leaves 404 rows for learning and 102 for testing. There is no law that says 80:20 is best; 70:30 would also be acceptable.

**12. What does `random_state=42` do?**
It fixes the random shuffle so the same split, and therefore the same results, are obtained every time.

**13. What is data leakage?**
Information from the test data influencing the training process, for example computing a median or scaling mean from all rows before splitting. It makes test scores look better than they truly are.

**14. How did you avoid data leakage?**
I split first, and put the imputer and scaler inside a scikit-learn `Pipeline`. The pipeline learns medians and scaling values from the training rows only and merely applies them to the test rows.

**15. Why use feature scaling?**
Features have very different ranges (`NOX` about 0.5, `TAX` about 400). Linear and Ridge Regression are affected by this, especially Ridge, whose penalty treats all coefficients equally.

**16. Why might tree models not require scaling?**
A tree only asks whether a feature is above or below a threshold. Rescaling a feature does not change the order of its values, so the splits stay equivalent.

**17. What did you do about outliers?**
I measured them with the IQR rule and kept them. They are real neighbourhoods rather than obvious errors, and tree-based models are robust to them.

**18. Why did you exclude column `B`?**
`B` is derived from the proportion of Black residents. Using a racial attribute to estimate prices is ethically problematic. A check showed that excluding it costs almost nothing: test RMSE 2.72 without `B` and 2.68 with it.

**19. What is unusual about the target values?**
16 houses are priced at exactly 50.0, which suggests the target was capped. Very expensive areas may therefore be under-predicted.

## C. Models

**20. What is Linear Regression?**
It fits a straight-line formula `price = b0 + b1·x1 + b2·x2 + ...` by minimising squared errors. It is simple but cannot capture curved relationships.

**21. What is Ridge Regression?**
Linear Regression with a penalty on large coefficients, controlled by `alpha`. It is more stable when features are correlated. In this project it performed almost exactly like Linear Regression.

**22. What is Decision Tree Regression?**
A tree of yes/no questions on the features. The prediction for a house is the average price of the training houses that end up in the same leaf.

**23. What is a Random Forest?**
An ensemble of many decision trees, each trained on a random sample of the rows and features. Their predictions are averaged, which reduces the overfitting of a single tree.

**24. What is Gradient Boosting?**
An ensemble in which trees are added one after another, and each new tree is trained to correct the errors of the ones before it.

**25. Why compare multiple models?**
No single algorithm is best for every dataset. Comparing a simple baseline with more powerful models shows how much extra complexity actually helps.

**26. What are overfitting and underfitting?**
Overfitting: the model learns training-specific detail and does well on training data but worse on new data. Underfitting: the model is too simple to capture the pattern, so it does poorly on both. Here the tuned Gradient Boosting overfits somewhat (training R² 0.997, test R² 0.901), while Linear and Ridge underfit (R² 0.73 training, 0.68 test).

## D. Evaluation

**27. What are MAE, MSE and RMSE?**
MAE is the average absolute error. MSE is the average squared error, which punishes large mistakes heavily. RMSE is the square root of MSE and is in the same unit as the price.

**28. What is R²?**
The proportion of the variation in price that the model explains. 1 is perfect and 0 means no better than always predicting the average.

**29. Which metric should be considered, and why?**
Not R² alone. RMSE and MAE show the typical error in price units, R² shows explained variation, and the gap between training and test scores shows overfitting. I also used cross-validation.

**30. What is cross-validation, and why did you use it?**
The training data is divided into folds (five here); each fold takes a turn as validation data while the model trains on the rest, and the scores are averaged. It gives a steadier estimate than one split, and I used it on the training data only so that the test set could not influence model choice.

**31. Why did the Decision Tree score better on the test set than in cross-validation?**
It scored R² 0.869 on the test set but 0.528 in cross-validation, with a large spread between folds (0.18). The test set has only 102 houses, so a single split can flatter or punish a model. This is why I chose the model by cross-validation.

**32. Which model did you select, and why?**
Gradient Boosting. It had the lowest cross-validated RMSE (3.66) and MAE and the highest cross-validated R² (0.84), and also the best test scores among the default models. After tuning it reached test RMSE 2.69, MAE 1.87 and R² 0.901.

**33. What does an RMSE of 2.69 mean in practice?**
A typical prediction is off by about 2.7 in units of $1000s, roughly $2,700; the MAE of 1.87 means the average absolute error is about $1,900. 78 % of test predictions were within $3,000 of the actual price.

## E. Analysis

**34. What is feature importance, and what did you find?**
It measures how much each feature contributes to a tree model's predictions. In the Random Forest, `RM` (0.56) and `LSTAT` (0.25) together account for about 81 %.

**35. Why is correlation not causation?**
Two variables can move together because of a third factor, or by coincidence. `LSTAT` correlates with price (-0.74), but that does not prove that changing `LSTAT` would change prices.

**36. What is residual analysis?**
A residual is `actual - predicted`. Plotting residuals shows whether errors are centred on zero and whether they have a pattern, for example growing with price, which would suggest something systematic is missing.

**37. What did your residual analysis show?**
Residuals had a mean of 0.44 and 94 % were within ±5. The largest error (+13.5) was a house priced at the cap of 50. The most expensive houses tended to be under-predicted, but only seven test houses were involved, so that is a hint and not a proven pattern.

**38. What is a good Actual vs Predicted plot?**
Points tightly clustered around the diagonal line (predicted = actual), with no curve or funnel shape.

## F. Implementation and limits

**39. Why save the whole pipeline with `joblib` and not just the model?**
New data must go through exactly the same imputation and scaling as the training data. Saving the pipeline guarantees that. Loading pickle files from unknown sources is unsafe, so only load files you trust.

**40. What are the limitations of the project, and how could it be improved?**
Limitations: overfitting; a small test set; a capped target; simple imputation; a small, old dataset from one city; the unit of `MEDV` is assumed. Improvements: repeated cross-validation and a wider hyper-parameter search, XGBoost/LightGBM, model-based imputation, log-transforming skewed variables, SHAP explanations, and a modern larger dataset.
