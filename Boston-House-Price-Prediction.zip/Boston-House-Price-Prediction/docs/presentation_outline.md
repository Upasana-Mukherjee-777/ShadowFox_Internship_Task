# Presentation Outline (10 slides, about 8-10 minutes)

Figure files are in `outputs/plots/`. Speaker notes are written to be said in your own words.

---

## Slide 1 - Title

**Bullets**
- Boston House Price Prediction using regression
- Your name, programme (B.Tech CSE AI & ML), institution, date

**Show:** title text only, or a small screenshot of the Streamlit app.

**Say:** "Good morning. My project predicts house prices in Boston neighbourhoods from features such as crime rate and number of rooms, using machine learning regression."

---

## Slide 2 - Problem Statement and Objective

**Bullets**
- Problem: predict the median house price from neighbourhood features
- Type: supervised learning, regression (the price is a continuous number)
- Objectives: preprocess the data, compare models, evaluate, save a final model, build a predictor

**Show:** the workflow line: Data -> Preprocess -> Split -> Train 5 models -> Evaluate -> Save -> Predict.

**Say:** "The task is regression because the price is a number, not a category. I wanted a complete, honest pipeline: clean data, several models, fair evaluation, and a working predictor."

---

## Slide 3 - Dataset

**Bullets**
- `HousingData.csv`: 506 rows, 14 columns; target is `MEDV`
- Features include CRIM, RM, LSTAT, PTRATIO, TAX, NOX
- 112 rows (22 %) have missing values in 6 columns; no duplicates
- 16 houses priced exactly at 50, so the target looks capped

**Show:** `01_missing_values.png` and a small table of the first rows (from the notebook).

**Say:** "I inspected the file before assuming anything. Six columns have 20 missing values each, which affects a fifth of the rows, so deleting them was not sensible. The price is also capped at 50, which I keep in mind when judging errors."

---

## Slide 4 - Data Preprocessing

**Bullets**
- Missing values: median imputation (most frequent for CHAS)
- Scaling: StandardScaler for Linear/Ridge only
- Split 80 % train (404) / 20 % test (102), `random_state=42`
- Everything inside a `Pipeline`, so there is no data leakage
- Column `B` excluded (ethical concern; accuracy is unchanged: RMSE 2.72 vs 2.68)

**Show:** a simple diagram: Split first -> Pipeline learns medians/means from training data only -> applies them to test data.

**Say:** "Data leakage means the test data influences training. I avoided it by splitting first and letting the pipeline learn every preprocessing value from the training rows only. I also dropped column B because it is derived from race, and I checked that this costs almost no accuracy."

---

## Slide 5 - Exploratory Data Analysis

**Bullets**
- Price is right-skewed; mean 22.5, median 21.2
- Strongest links to price: LSTAT (-0.74) and RM (+0.70)
- LSTAT-price relation is curved, so a straight line is not enough
- Some features overlap (RAD and TAX: 0.91)
- Correlation is not causation

**Show:** `03_correlation_heatmap.png` and `04_features_vs_price.png`.

**Say:** "More rooms means higher prices, and a higher share of lower-status population means lower prices. The LSTAT relation bends, which suggests non-linear models could do better. Correlation only shows association, not cause."

---

## Slide 6 - Models Used

**Bullets**
- Linear Regression (baseline) and Ridge Regression (penalised linear)
- Decision Tree (depth 5)
- Random Forest (200 trees)
- Gradient Boosting (trees that correct earlier errors)
- Compared by 5-fold cross-validation on the training data

**Show:** a five-row table: model, idea in one line, strength, weakness (from the report, Section 9).

**Say:** "I moved from a simple baseline to more powerful models. Trying several models shows whether the extra complexity is actually worth it."

---

## Slide 7 - Model Evaluation and Comparison

**Bullets**
- Metrics: MAE, MSE, RMSE, R²
- Test RMSE: Linear 4.86, Ridge 4.87, Decision Tree 3.10, Random Forest 3.01, Gradient Boosting 2.72
- Cross-validated RMSE: Gradient Boosting 3.66, Random Forest 4.13, Linear 5.09, Decision Tree 6.14
- Cross-validation, not the single test split, was used to choose the model

**Show:** `model_comparison.png` and the results table.

**Say:** "Tree ensembles clearly beat the linear models. The decision tree looked good on the test split but weak in cross-validation, because the test set has only 102 houses. That is why I chose the model by cross-validation and used the test set only once, at the end."

---

## Slide 8 - Final Model and Prediction System

**Bullets**
- Final model: tuned Gradient Boosting (400 trees, learning rate 0.1, depth 3)
- Saved as one pipeline with `joblib`
- `predict_price()` function, command-line tool, and Streamlit app
- Demo: predicted 23.48 vs actual 23.60 for a test house

**Show:** a screenshot of the Streamlit app after pressing Predict, or run it live.

**Say:** "The saved file contains the imputer and the model together, so new inputs get exactly the same preprocessing as training. Here I enter feature values, press Predict, and get a price."

---

## Slide 9 - Results

**Bullets**
- Test MAE 1.87, RMSE 2.69, R² 0.901 (prices in $1000s)
- 78 % of test predictions within ±3, 94 % within ±5
- Most important features: RM (0.56) and LSTAT (0.25)
- Honest caveat: training R² is 0.997, so the model overfits somewhat

**Show:** `actual_vs_predicted.png` and `residual_analysis.png`.

**Say:** "Points sit close to the diagonal, and residuals are centred near zero. The biggest miss is a house priced at the cap of 50. I also want to be clear that the training score is much higher than the test score, so the model overfits to some degree."

---

## Slide 10 - Conclusion and Future Scope

**Bullets**
- Gradient Boosting gave the best results; rooms and LSTAT drive predictions
- Limitations: overfitting, small test set, capped target, old single-city data
- Future work: wider tuning, XGBoost/LightGBM, better imputation, SHAP explanations, a modern dataset

**Show:** a short summary table; optionally the `train_vs_test_r2.png` chart.

**Say:** "To conclude, the project delivers a complete, reproducible pipeline and a working predictor. It is a learning model and not a valuation tool. With more time I would widen the tuning, try other ensembles and validate on newer data. Thank you; I am happy to take questions."
