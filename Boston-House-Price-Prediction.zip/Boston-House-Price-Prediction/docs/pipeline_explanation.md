# The Complete ML Pipeline in Simple Language

Think of the project as teaching a student to estimate house prices, then testing the student on houses they have never seen.

**1. Load and inspect.** We read `HousingData.csv`. It has 506 neighbourhoods, each described by 13 numbers plus the price (`MEDV`). Some cells say `NA` (unknown). We check what is missing, whether rows are repeated, and what the numbers look like before doing anything else.

**2. Choose the target and the features.** The price `MEDV` is what we want to predict (the "answer"). The other columns are clues (the "features"). We drop column `B` because it is based on the racial make-up of a town, which should not be used to price houses. Twelve clues remain.

**3. Split into train and test.** We put 80 % of the neighbourhoods (404) in a "study set" for the model to learn from, and lock away 20 % (102) as an "exam set". The exam set is opened only at the end. This shows how the model copes with houses it has not seen. A fixed random seed makes the split repeatable.

**4. Preprocess inside a pipeline.** Some clues are missing, so we fill each gap with the typical (median) value of that clue, calculated from the study set only. For the straight-line models we also rescale every clue to a common scale. A scikit-learn `Pipeline` bundles "fill gaps -> rescale -> model" into one object. This matters because it guarantees the exam set never influences the medians or scales (no data leakage).

**5. Train five different models.** Linear and Ridge Regression draw a straight-line formula. A Decision Tree asks a chain of yes/no questions. A Random Forest averages many trees. Gradient Boosting builds trees one after another, each fixing the mistakes of the previous ones.

**6. Compare fairly.** We use 5-fold cross-validation on the study set. The study set is cut into five parts and the model is trained on four and checked on the fifth, five times in turn. This gives a steadier score than a single check, and the exam set stays untouched.

**7. Pick and tune the best.** Gradient Boosting had the lowest cross-validated error, so we tried a small set of settings (number of trees, learning rate, depth) and kept the best combination.

**8. Take the exam.** Only now do we score the chosen model on the locked-away 102 houses. The metrics are:
- **MAE**: the average size of the mistake.
- **MSE**: the average squared mistake (big errors count extra).
- **RMSE**: the square root of MSE, in price units.
- **R²**: how much of the ups and downs in price the model explains.

Result: MAE 1.87, RMSE 2.69, R² 0.901 (in $1000s, assuming the original dataset's unit).

**9. Look closely at the mistakes.** The actual-vs-predicted chart and the residual plots show that most errors are small and centred on zero. The largest error is a house priced at 50, which looks like a cap in the data. We also note that the model scores 0.997 on the study set but 0.901 on the exam, meaning it has partly memorised its training data.

**10. Save and use.** We save the entire pipeline with `joblib`. To predict, `predict_price()` loads it, checks the inputs, fills any unknown value with the study-set median, and returns a price. The Streamlit app is a small form that calls the same function.

## In one line

*Load -> inspect -> split -> pipeline (fill gaps, rescale) -> train five models -> cross-validate -> tune the best -> test once -> analyse errors -> save -> predict.*

## Where each step lives in the code

| Step | File |
|---|---|
| Load, inspect, split, preprocessing pipeline | `src/data_preprocessing.py` |
| Models, cross-validation, tuning, saving | `src/train.py` |
| Metrics and plots | `src/evaluate.py` |
| Prediction | `src/predict.py`, `app.py` |
| Everything with explanations | `notebooks/Boston_House_Price_Prediction.ipynb` |
