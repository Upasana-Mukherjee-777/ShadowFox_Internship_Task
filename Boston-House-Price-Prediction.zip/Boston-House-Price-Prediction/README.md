# Boston House Price Prediction

A regression project that predicts median house prices from neighbourhood features (crime rate, number of rooms, tax rate, pupil-teacher ratio, and so on). It covers data inspection, preprocessing, exploratory analysis, comparison of five models, evaluation, a saved final model, a prediction script and a small Streamlit app.

## Problem statement

> Using the provided dataset containing features such as a number of rooms, crime rates, and other relevant factors, design and implement a regression model to accurately predict Boston house prices. The solution should involve data preprocessing, model selection, training, and evaluation.

## Objectives

1. Inspect the provided dataset and identify the target variable.
2. Handle missing values and scale features without data leakage.
3. Explore the data and find the features most related to price.
4. Train and compare Linear, Ridge, Decision Tree, Random Forest and Gradient Boosting regressors.
5. Evaluate with MAE, MSE, RMSE and R², select a final model and save it.
6. Provide a prediction function and a simple web interface.

## Dataset

| Item | Value |
|---|---|
| File | `data/HousingData.csv` |
| Size | 506 rows, 14 columns |
| Target | `MEDV` (median house price) |
| Features | `CRIM, ZN, INDUS, CHAS, NOX, RM, AGE, DIS, RAD, TAX, PTRATIO, B, LSTAT` |
| Missing values | 20 each in `CRIM, ZN, INDUS, CHAS, AGE, LSTAT` (112 rows affected); marked as `NA` |
| Duplicates | none |

The file has no data dictionary, so the unit of `MEDV` is not stated. Plots and the prediction output assume it is in $1000s, as in the original Boston Housing dataset.

**Column `B` is excluded from the model.** It is derived from the proportion of Black residents, which is ethically problematic to use for pricing. A check in the notebook shows that dropping it does not meaningfully change accuracy (test RMSE 2.72 without `B`, 2.68 with it). To include it, set `INCLUDE_B = True` in `src/data_preprocessing.py` and re-run `python src/train.py`.

## Technologies

Python 3, pandas, NumPy, matplotlib, seaborn, scikit-learn, joblib, Jupyter, Streamlit.

## Machine learning workflow

1. Load the CSV (`NA` becomes `NaN`) and inspect it.
2. Split 80 % / 20 % into training and test sets (`random_state=42`).
3. Build a scikit-learn `Pipeline`: imputation (median; most frequent for `CHAS`), scaling (Linear/Ridge only), then the model. Everything is fitted on training data only, which prevents data leakage.
4. Compare five models with 5-fold cross-validation on the training data.
5. Pick the model with the lowest cross-validated RMSE, tune it with a small grid search, and evaluate it once on the test set.
6. Save the whole pipeline with `joblib` and use it for predictions.

## Models tested

Linear Regression, Ridge Regression, Decision Tree (`max_depth=5`), Random Forest (200 trees), Gradient Boosting.

## Evaluation metrics

MAE (average absolute error), MSE (average squared error), RMSE (square root of MSE, same unit as price) and R² (share of price variation explained).

## Results

All figures below come from the run stored in `outputs/results/` (test set = 102 houses; error values in $1000s).

| Model | MAE | MSE | RMSE | R² | CV RMSE (train) |
|---|---|---|---|---|---|
| Linear Regression | 3.079 | 23.659 | 4.864 | 0.677 | 5.091 |
| Ridge Regression | 3.075 | 23.673 | 4.865 | 0.677 | 5.088 |
| Decision Tree | 2.467 | 9.625 | 3.102 | 0.869 | 6.141 |
| Random Forest | 2.049 | 9.038 | 3.006 | 0.877 | 4.125 |
| Gradient Boosting | 1.906 | 7.386 | 2.718 | 0.899 | 3.664 |
| **Gradient Boosting (tuned) - final** | **1.868** | **7.246** | **2.692** | **0.901** | 3.596 |

* The final model is the tuned Gradient Boosting pipeline (400 trees, learning rate 0.1, depth 3).
* Its training R² is 0.997 against 0.901 on the test set, so it overfits to a noticeable degree. The test figures are the ones that describe performance on new data.
* `RM` (rooms) and `LSTAT` (lower-status population) are the most influential features (about 81 % of Random Forest importance together).
* The Decision Tree looks better on the test split (R² 0.869) than in cross-validation (0.528). With only 102 test rows one split can be misleading, which is why cross-validation drives model selection.

## Real results versus limitations

* Every number above was produced by running the code in this repository; nothing is estimated or copied.
* The Streamlit app was tested with Streamlit's headless `AppTest` (load and press *Predict*); it was not opened in a browser during development.
* The 16 houses priced at exactly 50 suggest the target was capped, so very expensive areas are under-predicted.
* The data is a small, old snapshot from one city. The model is a learning exercise and must not be used to value real property.

## Installation

```bash
cd Boston-House-Price-Prediction
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

The saved `models/best_model.pkl` was created with scikit-learn 1.8. If you use a different version and loading fails, simply run `python src/train.py` to rebuild it. Only load `.pkl` files you trust.

## How to run

**Notebook (full walkthrough with explanations and plots)**

```bash
jupyter notebook notebooks/Boston_House_Price_Prediction.ipynb
```

Run the cells top to bottom. The notebook already contains saved outputs.

**Train from the command line** (compares models, tunes, saves the model, tables and plots)

```bash
python src/train.py
python src/evaluate.py      # reloads the saved model and re-checks the test metrics
```

**Prediction system**

```bash
python src/predict.py --example        # a real house from the test set, with its actual price
python src/predict.py --json '{"CRIM": 0.1, "ZN": 0, "INDUS": 7.0, "CHAS": 0, "NOX": 0.5, "RM": 6.5, "AGE": 60, "DIS": 4.0, "RAD": 4, "TAX": 300, "PTRATIO": 18, "LSTAT": 10}'
```

Every feature must be supplied; use `null` for a value you do not know and it will be filled with the training median. On Windows, quoting JSON on the command line is awkward: save it in a file such as `house.json` and pass `--json house.json` instead. In Python:

```python
from predict import predict_price          # run from inside src/
predict_price({"CRIM": 0.1, "ZN": 0, "INDUS": 7.0, "CHAS": 0, "NOX": 0.5, "RM": 6.5,
               "AGE": 60, "DIS": 4.0, "RAD": 4, "TAX": 300, "PTRATIO": 18, "LSTAT": 10})
```

**Streamlit app**

```bash
streamlit run app.py
```

Enter the feature values, press **Predict**, and the predicted price is shown.

## Project structure

```
Boston-House-Price-Prediction/
├── data/
│   └── HousingData.csv               # the provided dataset (unchanged)
├── notebooks/
│   └── Boston_House_Price_Prediction.ipynb
├── src/
│   ├── data_preprocessing.py         # loading, inspection, split, preprocessing pipeline
│   ├── train.py                      # model comparison, tuning, saving
│   ├── evaluate.py                   # metrics and evaluation plots
│   └── predict.py                    # prediction from the saved model
├── models/
│   ├── best_model.pkl                # saved pipeline (preprocessing + model)
│   └── model_metadata.json           # feature list and training ranges
├── outputs/
│   ├── plots/                        # all figures (PNG)
│   └── results/                      # comparison tables, metrics, importances
├── docs/
│   ├── pipeline_explanation.md       # the whole pipeline in simple language
│   ├── viva_questions.md             # 40 viva questions with answers
│   └── presentation_outline.md       # 10-slide presentation plan
├── app.py                            # Streamlit interface
├── README.md
├── report.md
└── requirements.txt
```

This is the suggested structure plus `app.py` (the optional interface) and a `docs/` folder for the viva and presentation material. The notebook imports its core functions from `src/` so the notebook and the scripts always give the same numbers.

## Future scope

Wider hyper-parameter search and repeated cross-validation; XGBoost/LightGBM and stacking; model-based imputation; log-transforming the skewed target and `CRIM`; SHAP explanations and prediction intervals; testing on a modern, larger housing dataset; deploying the app online.
