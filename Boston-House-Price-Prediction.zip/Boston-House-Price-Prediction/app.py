"""
app.py - a small Streamlit interface for the Boston house-price model.

Run from the project root:
    streamlit run app.py
"""

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from predict import format_price, load_metadata, load_model, predict_price  # noqa: E402

# Plain-English descriptions of the columns (standard meanings of the
# well-known Boston Housing variables).
DESCRIPTIONS = {
    "CRIM": "Per-capita crime rate",
    "ZN": "Share of residential land zoned for large lots (%)",
    "INDUS": "Share of non-retail business acres (%)",
    "CHAS": "Borders the Charles River? (1 = yes, 0 = no)",
    "NOX": "Nitric oxide concentration",
    "RM": "Average number of rooms per dwelling",
    "AGE": "Share of older owner-occupied homes (%)",
    "DIS": "Distance to employment centres",
    "RAD": "Index of accessibility to radial highways",
    "TAX": "Property-tax rate",
    "PTRATIO": "Pupil-teacher ratio",
    "LSTAT": "Lower-status population (%)",
}

st.set_page_config(page_title="Boston House Price Predictor", page_icon="\U0001F3E0")


@st.cache_resource
def get_model():
    return load_model()


st.title("Boston House Price Predictor")
st.caption("Enter the neighbourhood and house details, then press Predict.")

try:
    model = get_model()
    meta = load_metadata()
except FileNotFoundError:
    st.error("Model not found. Run `python src/train.py` first.")
    st.stop()

features = meta["features"]
stats = meta["feature_stats_train"]

inputs = {}
left, right = st.columns(2)
for i, name in enumerate(features):
    column = left if i % 2 == 0 else right
    lo, med, hi = stats[name]["min"], stats[name]["median"], stats[name]["max"]
    with column:
        if name == "CHAS":
            inputs[name] = float(st.selectbox(f"{name} - {DESCRIPTIONS.get(name, '')}", [0, 1]))
        else:
            inputs[name] = st.number_input(
                f"{name} - {DESCRIPTIONS.get(name, '')}",
                min_value=float(lo), max_value=float(hi), value=float(med),
                help=f"Range seen in training data: {lo:g} to {hi:g}")

if st.button("Predict", type="primary"):
    price = predict_price(inputs, model)
    st.success(f"Predicted house price: {format_price(price)}")
    st.caption(f"Model: {meta['model_name']}. Values are limited to the range seen in "
               "the training data. This is a statistical estimate, not a valuation.")
